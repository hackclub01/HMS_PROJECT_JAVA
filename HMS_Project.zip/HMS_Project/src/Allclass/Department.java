package Allclass;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;

public class Department extends JFrame implements ActionListener {
	JPanel panel;

	Department() {
		panel = new JPanel();
		panel.setBounds(5, 5, 1990, 890);
		panel.setLayout(null);
		panel.setBackground(new Color(90, 156, 163));
		add(panel);

		// Update column names to include "Doctor Name"
		String ColumnName[] = { "ID", "Department", "Phone Number", "Doctor Name" };
		DefaultTableModel model = new DefaultTableModel(ColumnName, 0);
		JTable table = new JTable(model);
		table.setBounds(5, 50, 990, 350);
		table.setBackground(new Color(90, 156, 163));
		table.setFont(new Font("Tahoma", Font.BOLD, 14));
		panel.add(table);
		table.getColumnModel().getColumn(3).setPreferredWidth(200);

		// Update SQL query to fetch department name, phone number, and doctor names
		try {
			DB_conn c = new DB_conn();
			String q = "SELECT d.id, d.dpt_name, d.dpt_phone, GROUP_CONCAT(dr.name SEPARATOR ', ') AS doctor_names " +
            "FROM department d " +
            "LEFT JOIN dr ON d.dpt_name = dr.dpt_name " +
            "GROUP BY d.id, d.dpt_name, d.dpt_phone;";




			ResultSet resultSet = c.sObj.executeQuery(q);

			while (resultSet.next()) {
				String id = resultSet.getString("id");
				String dpt = resultSet.getString("dpt_name");
				String phone = resultSet.getString("dpt_phone");
				String doctorNames = resultSet.getString("doctor_names"); // This will be a comma-separated list of
																			// doctor names

				model.addRow(new Object[] { id, dpt, phone, doctorNames });
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		JLabel label0 = new JLabel("ID");
		label0.setBounds(5, 11, 105, 20);
		label0.setFont(new Font("Tahoma", Font.BOLD, 14));
		panel.add(label0);

		JLabel label1 = new JLabel("Department");
		label1.setBounds(255, 11, 105, 20);
		label1.setFont(new Font("Tahoma", Font.BOLD, 14));
		panel.add(label1);

		JLabel label2 = new JLabel("Phone Number");
		label2.setBounds(490, 11, 150, 20);
		label2.setFont(new Font("Tahoma", Font.BOLD, 14));
		panel.add(label2);

		JLabel label3 = new JLabel("Doctor Name");
		label3.setBounds(760, 11, 150, 20);
		label3.setFont(new Font("Tahoma", Font.BOLD, 14));
		panel.add(label3);

		JButton b1 = new JButton("BACK");
		b1.setBounds(970, 650, 130, 30);
		b1.setBackground(Color.red);
		b1.setForeground(Color.black);
		panel.add(b1);
		b1.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
			}
		});

		   table.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                if (!e.getValueIsAdjusting()) { // Ensure that the event is not triggered multiple times
                    int selectedRow = table.getSelectedRow();
                    if (selectedRow != -1) {
                        String selectedDepartment = model.getValueAt(selectedRow, 1).toString();
                      // Open form with the selected department
                    }
                }
            }
        });

		setUndecorated(true);
		setLayout(null);
		setBounds(251, 24, 1116, 750);
		setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// Handle action events here if needed
	}

	public static void main(String[] args) {
		new Department();
	}
}
