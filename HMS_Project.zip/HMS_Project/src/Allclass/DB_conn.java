package Allclass;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
public class DB_conn {

	Connection conObj;
	Statement sObj;

	public DB_conn() {
		try {
			com.mysql.jdbc.Driver dObj = new com.mysql.jdbc.Driver();
			// DriverManager.registerDriver(dObj);
			DriverManager.registerDriver(dObj);
			conObj = DriverManager
					.getConnection("jdbc:mysql://localhost/hms?characterEncoding=UTF-8", "root", "");
			sObj = conObj.createStatement();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}
}