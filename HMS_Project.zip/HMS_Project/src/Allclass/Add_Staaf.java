package Allclass;

import java.awt.Choice;
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

public class Add_Staaf extends JFrame implements ActionListener {
    JComboBox<String> comboBox;
    JTextField textFieldNumber, textName, textAge, textFieldContact;
    JRadioButton r1, r2;
    Choice c3;
    JButton b1, b2;

    Add_Staaf() {
        JPanel panel = new JPanel();
        panel.setBounds(5, 5, 1200, 900);
        panel.setBackground(new Color(180, 116, 113));
        panel.setLayout(null);
        add(panel);

        // Image Section
        ImageIcon imageIcon = new ImageIcon(ClassLoader.getSystemResource("icon/staf.jpeg"));
        Image image = imageIcon.getImage().getScaledInstance(250, 250, Image.SCALE_SMOOTH);
        JLabel label = new JLabel(new ImageIcon(image));
        label.setBounds(590, 70, 290, 290);
        panel.add(label);

        JLabel labelName = new JLabel("NEW STAF FORM");
        labelName.setBounds(160, 8, 260, 53);
        labelName.setFont(new Font("Tahoma", Font.BOLD, 24));
        panel.add(labelName);

        // ID Label and ComboBox
        JLabel labelID = new JLabel("ID :");
        labelID.setBounds(145, 76, 200, 16);
        labelID.setFont(new Font("Tahoma", Font.BOLD, 16));
        labelID.setForeground(Color.white);
        panel.add(labelID);

        comboBox = new JComboBox<>(new String[] { "Aadhar card", "Pan Card" });
        comboBox.setBounds(350, 73, 150, 20);
        comboBox.setBackground(new Color(3, 45, 48));
        comboBox.setForeground(Color.white);
        comboBox.setFont(new Font("Tahoma", Font.BOLD, 16));
        panel.add(comboBox);

        // Number Field
        JLabel labelNumber = new JLabel("Number :");
        labelNumber.setBounds(145, 111, 200, 16);
        labelNumber.setFont(new Font("Tahoma", Font.BOLD, 16));
        labelNumber.setForeground(Color.white);
        panel.add(labelNumber);

        textFieldNumber = new JTextField();
        textFieldNumber.setBounds(350, 111, 150, 20);
        panel.add(textFieldNumber);

        // Name Field
        JLabel labelName1 = new JLabel("Name :");
        labelName1.setBounds(145, 151, 200, 16);
        labelName1.setFont(new Font("Tahoma", Font.BOLD, 16));
        labelName1.setForeground(Color.white);
        panel.add(labelName1);

        textName = new JTextField();
        textName.setBounds(350, 151, 150, 20);
        panel.add(textName);

        // Gender
        JLabel labelGender = new JLabel("Gender :");
        labelGender.setBounds(145, 191, 200, 16);
        labelGender.setFont(new Font("Tahoma", Font.BOLD, 16));
        labelGender.setForeground(Color.white);
        panel.add(labelGender);

        r1 = new JRadioButton("Male");
        r1.setFont(new Font("Tahoma", Font.BOLD, 16));
        r1.setForeground(Color.white);
        r1.setBackground(new Color(109, 164, 170));
        r1.setBounds(350, 191, 80, 15);
        panel.add(r1);

        r2 = new JRadioButton("Female");
        r2.setFont(new Font("Tahoma", Font.BOLD, 16));
        r2.setForeground(Color.white);
        r2.setBackground(new Color(109, 164, 170));
        r2.setBounds(430, 191, 80, 15);
        panel.add(r2);

        // Category Field
        JLabel labelCategory = new JLabel("Category :");
        labelCategory.setBounds(145, 231, 200, 16);
        labelCategory.setFont(new Font("Tahoma", Font.BOLD, 16));
        labelCategory.setForeground(Color.white);
        panel.add(labelCategory);

        c3 = new Choice();
        c3.setBounds(350, 230, 150, 25);
        c3.add("Nurse");
        c3.add("WardBoy");
        c3.add("Caregiver");
        c3.add("Cleaner");
        c3.add("Attendant");
        panel.add(c3);

        // Contact Field
        JLabel contact = new JLabel("Contact :");
        contact.setBounds(145, 270, 170, 17);
        contact.setFont(new Font("Tahoma", Font.BOLD, 16));
        contact.setForeground(Color.white);
        panel.add(contact);

        textFieldContact = new JTextField();
        textFieldContact.setBounds(350, 270, 150, 20);
        panel.add(textFieldContact);

        // Age Field
        JLabel labelAge = new JLabel("Age :");
        labelAge.setBounds(145, 300, 200, 16);
        labelAge.setFont(new Font("Tahoma", Font.BOLD, 16));
        labelAge.setForeground(Color.white);
        panel.add(labelAge);

        textAge = new JTextField();
        textAge.setBounds(350, 300, 150, 20);
        panel.add(textAge);

        // Buttons
        b1 = new JButton("ADD");
        b1.setBounds(145, 430, 120, 30);
        b1.setForeground(Color.WHITE);
        b1.setBackground(Color.black);
        b1.addActionListener(this);
        panel.add(b1);

        b2 = new JButton("Back");
        b2.setBounds(350, 430, 120, 30);
        b2.setForeground(Color.WHITE);
        b2.setBackground(Color.black);
        b2.addActionListener(e -> setVisible(false));
        panel.add(b2);

        setUndecorated(true);
        setSize(850, 550);
        setLayout(null);
        setBounds(251, 24, 1116, 750);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == b1) {
            String radioBTN = r1.isSelected() ? "Male" : (r2.isSelected() ? "Female" : null);

            String s1 = textFieldNumber.getText();
            String s2 = textName.getText();
            String s3 = textAge.getText();
            String s6 = textFieldContact.getText();
            String s4 = radioBTN;
            String s5 = c3.getSelectedItem();

            boolean isValid = true;

            // Validation for Number (s1)
            if (s1 == null || s1.isEmpty() || s1.length() != 12) {
                isValid = false;
                JOptionPane.showInternalMessageDialog(null, "Number must be exactly 12 characters");
            }

            // Validation for Name (s2)
            if (s2 == null || s2.isEmpty() || s2.length() < 2 || !s2.matches("[a-zA-Z]+")) {
                isValid = false;
                JOptionPane.showInternalMessageDialog(null, "Name must be at least 2 characters and contain only letters");
            }

            // Validation for Age (s3)
            try {
                int age = Integer.parseInt(s3);
                if (age < 0 || age > 99) {
                    isValid = false;
                    JOptionPane.showInternalMessageDialog(null, "Age must be between 0 and 99");
                }
            } catch (NumberFormatException ex) {
                isValid = false;
                JOptionPane.showInternalMessageDialog(null, "Age must be a valid number");
            }

            // Validation for Gender (s4)
            if (s4 == null) {
                isValid = false;
                JOptionPane.showInternalMessageDialog(null, "Please select a gender");
            }

            // Validation for Category (s5)
            if (s5 == null || s5.isEmpty()) {
                isValid = false;
                JOptionPane.showInternalMessageDialog(null, "Please select a category");
            }

            // Validation for Contact (s6)
            if (s6 == null || s6.isEmpty() || !s6.matches("\\d{10}")) {
                isValid = false;
                JOptionPane.showInternalMessageDialog(null, "Contact must be a 10-digit number");
            }

            if (isValid) {
                try {
                    DB_conn c = new DB_conn();
                    String q = "INSERT INTO staf_info VALUES('" + s1 + "','" + s2 + "','" + s3 + "','" + s4 + "','" + s5 + "','" + s6 + "')";
                    c.sObj.executeUpdate(q);
                    JOptionPane.showMessageDialog(null, "Added Successfully");
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            } else {
                JOptionPane.showMessageDialog(null, "Please correct the highlighted fields");
            }
        }
    }

    public static void main(String[] args) {
        new Add_Staaf();
    }
}
