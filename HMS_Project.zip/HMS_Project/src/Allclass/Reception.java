package Allclass;

import java.awt.Color;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;


public class Reception extends JFrame implements ActionListener {
	public Reception() {

		JFrame frame = new JFrame();

		// --------------------Slide Label------------------------
		JPanel panel = new JPanel();
		panel.setLayout(null);
		panel.setBounds(0, 0, 250, 900);
		panel.setBackground(Color.decode("#85d4e3"));
		panel.setVisible(true);
		frame.add(panel);

		// --------------------MAIN Frame------------------------
		JPanel panel2 = new JPanel();
		panel2.setLayout(null);
		panel2.setBounds(190, 0, 1200, 1000);
		panel2.setBackground(Color.cyan);
		frame.add(panel2);

		// Image---------------------Slide Panel--------------------------
		ImageIcon img1 = new ImageIcon(ClassLoader.getSystemResource("icon/paint.png"));
		Image img2 = img1.getImage().getScaledInstance(280, 250, Image.SCALE_SMOOTH);
		ImageIcon img3 = new ImageIcon(img2);
		JLabel label = new JLabel(img3);
		label.setBounds(-108, -10, 450, 230);
		panel.add(label);

		// --------------------------------------------Image Main Panel------------
		ImageIcon img11 = new ImageIcon(ClassLoader.getSystemResource("icon/hospital2.jpg"));
		Image img12 = img11.getImage().getScaledInstance(panel2.getWidth(), panel2.getHeight(), Image.SCALE_SMOOTH);
		ImageIcon img13 = new ImageIcon(img12);
		JLabel label3 = new JLabel(img13);
		// label3.setBounds(-10,-50,1200, 800);
		// Assuming panel2 is the container for label3
		label3.setBounds(-10, -50, panel2.getWidth(), panel2.getHeight());
		frame.getContentPane().add(label3);
		panel2.add(label3);

		// ------------------------Button Startiing----------------
		JButton btn1 = new JButton("Add New Patient");
		btn1.setBounds(3, 230, 100, 30);
		btn1.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				new Add_patient();
			}
		});
		panel.add(btn1);

		JButton btn2 = new JButton("Discharge Patient");
		btn2.setBounds(130, 230, 100, 30);
		// btn2.setBackground(Color.decode("#85d4e3"));
		btn2.setForeground( Color.black); 
		btn2.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				new Discharge();
			}
		});
		panel.add(btn2);

		JButton btn3 = new JButton("Department");
		btn3.setBounds(3, 280, 100, 30);
		btn3.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				new Department();
			}
		});
		panel.add(btn3);

		JButton btn4 = new JButton("Dr_info");
		btn4.setBounds(130, 280, 100, 30);
		btn4.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				new Dr_info();
			}
		});
		panel.add(btn4);

		JButton btn5 = new JButton("Patient Info");
		btn5.setBounds(130, 330, 100, 30);
		btn5.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				new patient_info();
			}
		});
		panel.add(btn5);

		JButton btn6 = new JButton("Add Staf");
		btn6.setBounds(3, 330, 100, 30);
		// btn6.setBackground(Color.red);
		btn6.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				new Add_Staaf();

			}
		});
		panel.add(btn6);

		JButton btn7 = new JButton("Dr");
		btn7.setBounds(3, 380, 100, 30);
		btn7.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				new Dr_Main();
			}
		});
		panel.add(btn7);

		JButton btn8 = new JButton("Staff");
		btn8.setBounds(130, 380, 100, 30);
		btn8.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				new staf_Info();
			}
		});
		panel.add(btn8);

		// setSize(2000,1200);
		// frame.setUndecorated(true);

		frame.setBounds(0, 0, 2450, 1700);
		frame.getContentPane().setBackground(Color.darkGray);
		frame.setExtendedState(JFrame.MAXIMIZED_BOTH);

		frame.setLayout(null);
		frame.setVisible(true);
		panel.add(panel);

	}
	@Override
	public void actionPerformed(ActionEvent e) {

	}

	public static void main(String[] args) {
		new Reception();
	}
}
