package Allclass;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

// import net.proteanit.sql.DbUtils;

public class staf_Info extends JFrame implements ActionListener {

	staf_Info() {
		JPanel panel = new JPanel();
		panel.setBounds(5, 5, 1990, 890);
		panel.setBackground(new Color(109, 164, 170));
		panel.setLayout(null);
		add(panel);
		// -----------------------Creating Tabel And column------------------

		String[] columnName = { "Name", "Age", "Number", "Gender", "ID" };
		DefaultTableModel model = new DefaultTableModel(columnName, 0);
		JTable table = new JTable(model);
		table.setBounds(10, 34, 980, 450);
		table.setBackground(new Color(109, 164, 170));
		table.setFont(new Font("Tahoma", Font.BOLD, 12));
		panel.add(table);

		try {
			DB_conn c = new DB_conn();
		String q = "SELECT * FROM staf_info";

			ResultSet resultSet = c.sObj.executeQuery(q);
			// table.setModel(DbUtils.resultSetToTableModel(resultSet));

			while (resultSet.next()) {
				String age = resultSet.getString("age");
				String id = resultSet.getString("id_card");
				String number = resultSet.getString("phone");
				String name = resultSet.getString("name");
				String gender = resultSet.getString("gender");

				model.addRow(new Object[] { name, age, number, gender, id });

			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		JLabel label1 = new JLabel("Name");
		label1.setBounds(0, 9, 70, 20);
		label1.setFont(new Font("Tahoma", Font.BOLD, 14));
		panel.add(label1);

		JLabel label2 = new JLabel("Age");
		label2.setBounds(190, 9, 70, 20);
		label2.setFont(new Font("Tahoma", Font.BOLD, 14));
		panel.add(label2);

		JLabel label3 = new JLabel("P.Number");
		label3.setBounds(400, 9, 150, 20);
		label3.setFont(new Font("Tahoma", Font.BOLD, 14));
		panel.add(label3);

		JLabel label33 = new JLabel("Gender");
		label33.setBounds(540, 9, 150, 20);
		label33.setFont(new Font("Tahoma", Font.BOLD, 14));
		panel.add(label33);

		

		JLabel label0 = new JLabel("ID");
		label0.setBounds(850, 9, 150, 20);
		label0.setFont(new Font("Tahoma", Font.BOLD, 14));
		panel.add(label0);

		// --------------------------Button FOR
		// BACK----------------------------------------------
		JButton button = new JButton("BACK");
		button.setBounds(900, 655, 100, 30);
		// button.setBackground(Color.BLACK);
		button.setFont(new Font("Tahoma", Font.BOLD, 14));

		button.setForeground(Color.black);
		panel.add(button);
		button.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
			}
		});
		// --------------------------Button FOR
		// Find----------------------------------------------

		JButton find = new JButton("Find");
		find.setForeground(Color.black);
		find.setFont(new Font("Tahoma", Font.BOLD, 14));
		find.setBounds(999, 655, 100, 30);
		find.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {

				String find = JOptionPane.showInputDialog("Name Here");
				try {
					DB_conn c = new DB_conn();
					String q2 = "select * from staf_info where name='" + find + "'";
					ResultSet resultSet = c.sObj.executeQuery(q2);
					model.setRowCount(0);
					while (resultSet.next()) {
						JPanel panel = new JPanel();
						panel.setBounds(5, 5, 1990, 890);
						panel.setBackground(new Color(109, 164, 170));
						panel.setLayout(null);

						add(panel);
						
						try {
							String age = resultSet.getString("age");
							String id = resultSet.getString("id_card");
							String number = resultSet.getString("phone");
							String name = resultSet.getString("name");
								String gender = resultSet.getString("gender");
							
		
							model.addRow(new Object[] { name, age, number, gender,  id });
								
						} catch (Exception e20) {
							// TODO: handle exception
							e20.printStackTrace();
						}
						// JOptionPane.showInternalMessageDialog(null, "s");
						
					}
					if (model.getRowCount() == 0) {
						JOptionPane.showMessageDialog(null, "No records found for ID: " + find); 
					}
				} catch (Exception e2) {
					e2.printStackTrace();
					;
				}

			}

		});
		panel.add(find);

		setUndecorated(true);
		setSize(1000, 600);
		// setLocation(350, 230);
		setBounds(251, 24, 1116, 750);	

		setLayout(null);
		setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {

	}

	public static void main(String[] args) {
		new staf_Info();
	}
}
