package Allclass;

import java.awt.Choice;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class Discharge extends JFrame implements ActionListener {

	String selectedNumber, demo;
	int check = 0;

	Discharge() {

		JPanel panel = new JPanel();
		// panel.setBounds(405,5,990,790);
		panel.setBounds(5, 5, 1116, 750);

		panel.setBackground(new Color(90, 156, 163));
		panel.setLayout(null);
		add(panel);

		JLabel label = new JLabel("CHECK-OUT");
		label.setBounds(450, 20, 150, 20);
		label.setFont(new Font("Tahoma", Font.BOLD, 20));
		label.setForeground(Color.white);
		panel.add(label);

		JLabel label2 = new JLabel("Customer Id");
		label2.setBounds(350, 80, 150, 20);
		label2.setFont(new Font("Tahoma", Font.BOLD, 14));
		label2.setForeground(Color.white);
		panel.add(label2);

		Choice choice = new Choice();
		choice.setBounds(520, 80, 150, 25);
		panel.add(choice);

		try {
			DB_conn c = new DB_conn();
			ResultSet resultSet = c.sObj.executeQuery("select * from Patient_Info");
			while (resultSet.next()) {
				choice.add(resultSet.getString("number"));
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		JLabel label3 = new JLabel("Patient Name");
		label3.setBounds(350, 120, 145, 20);
		label3.setFont(new Font("Tahoma", Font.BOLD, 14));
		label3.setForeground(Color.white);
		panel.add(label3);

		JLabel RNo = new JLabel();
		RNo.setBounds(520, 120, 145, 20);
		RNo.setFont(new Font("Tahoma", Font.BOLD, 14));
		RNo.setForeground(Color.white);
		panel.add(RNo);

		JLabel label4 = new JLabel("In Time");
		label4.setBounds(350, 160, 150, 20);
		label4.setFont(new Font("Tahoma", Font.BOLD, 14));
		label4.setForeground(Color.white);
		panel.add(label4);

		JLabel INTime = new JLabel();
		INTime.setBounds(520, 160, 250, 20);
		INTime.setFont(new Font("Tahoma", Font.BOLD, 14));
		INTime.setForeground(Color.white);
		panel.add(INTime);

		JLabel label5 = new JLabel("Out Time");
		label5.setBounds(350, 200, 150, 20);
		label5.setFont(new Font("Tahoma", Font.BOLD, 14));
		label5.setForeground(Color.white);
		panel.add(label5);

		Date date = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); // Use "HH:mm:ss" for 24-hour format

		JLabel OUTTime = new JLabel(sdf.format(date)); // Format the date
		OUTTime.setBounds(520, 200, 250, 20);
		OUTTime.setFont(new Font("Tahoma", Font.BOLD, 14));
		OUTTime.setForeground(Color.white);
		panel.add(OUTTime);

		JLabel labelG = new JLabel("Gender");
		labelG.setBounds(350, 235, 145, 20);
		labelG.setFont(new Font("Tahoma", Font.BOLD, 14));
		labelG.setForeground(Color.white);
		panel.add(labelG);

		JLabel RNO1 = new JLabel();
		RNO1.setBounds(520, 235, 145, 20);
		RNO1.setFont(new Font("Tahoma", Font.BOLD, 14));
		RNO1.setForeground(Color.white);
		panel.add(RNO1);

		JLabel d33 = new JLabel("Deposit");
		d33.setBounds(350, 260, 145, 20);
		d33.setFont(new Font("Tahoma", Font.BOLD, 14));
		d33.setForeground(Color.white);
		panel.add(d33);

		JLabel d3 = new JLabel();
		d3.setBounds(520, 260, 145, 20);
		d3.setFont(new Font("Tahoma", Font.BOLD, 14));
		d3.setForeground(Color.white);
		panel.add(d3);

		JLabel d = new JLabel("Disease");
		d.setBounds(350, 290, 145, 20);
		d.setFont(new Font("Tahoma", Font.BOLD, 14));
		d.setForeground(Color.white);
		panel.add(d);

		JLabel d2 = new JLabel();
		d2.setBounds(520, 290, 145, 20);
		d2.setFont(new Font("Tahoma", Font.BOLD, 14));
		d2.setForeground(Color.white);
		panel.add(d2);

		JLabel dr_f = new JLabel("Dr_fees");
		dr_f.setBounds(350, 315, 145, 20);
		dr_f.setFont(new Font("Tahoma", Font.BOLD, 14));
		dr_f.setForeground(Color.white);
		panel.add(dr_f);

		JLabel dr_f2 = new JLabel();
		dr_f2.setBounds(520, 315, 145, 20);
		dr_f2.setFont(new Font("Tahoma", Font.BOLD, 14));
		dr_f2.setForeground(Color.white);
		panel.add(dr_f2);

		JLabel room_c = new JLabel("room_charge");
		room_c.setBounds(350, 340, 145, 20);
		room_c.setFont(new Font("Tahoma", Font.BOLD, 14));
		room_c.setForeground(Color.white);
		panel.add(room_c);

		JLabel room_c2 = new JLabel();
		room_c2.setBounds(520, 340, 145, 20);
		room_c2.setFont(new Font("Tahoma", Font.BOLD, 14));
		room_c2.setForeground(Color.white);
		panel.add(room_c2);

		JLabel extra = new JLabel("extra Charge");
		extra.setBounds(350, 370, 145, 20);
		extra.setFont(new Font("Tahoma", Font.BOLD, 14));
		extra.setForeground(Color.white);
		panel.add(extra);

		JLabel extra2 = new JLabel();
		extra2.setBounds(520, 370, 145, 20);
		extra2.setFont(new Font("Tahoma", Font.BOLD, 14));
		extra2.setForeground(Color.white);
		panel.add(extra2);

		JLabel total = new JLabel("TOTAL:-");
		total.setBounds(350, 399, 145, 20);
		total.setFont(new Font("Tahoma", Font.BOLD, 14));
		total.setForeground(Color.green);
		panel.add(total);

		JLabel total2 = new JLabel();
		total2.setBounds(520, 399, 145, 20);
		total2.setFont(new Font("Tahoma", Font.BOLD, 14));
		total2.setForeground(Color.green);
		panel.add(total2);

		JButton discharge = new JButton("Discharge");
		discharge.setBounds(230, 500, 120, 30);
		discharge.setBackground(Color.black);
		discharge.setForeground(Color.white);
		discharge.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				DB_conn c = new DB_conn();
				try {
					ResultSet rs = c.sObj.executeQuery(
							"select r_no from patient_info where number= '" + choice.getSelectedItem() + "' ");
					if (rs.next()) {
						String rNo = rs.getString("r_no");
						// JOptionPane.showMessageDialog(null, "Checking-------" + rNo);

						if (rNo != null) {
							c.sObj.executeUpdate(
									"delete from Patient_Info where number = '" + choice.getSelectedItem() + "'");
							c.sObj.executeUpdate("update room set status = 'Available' where id = '" + rNo + "'");

							JOptionPane.showMessageDialog(null, "Done");
						} else {
							JOptionPane.showMessageDialog(null, "Room number is null.");
						}
					}
				} catch (Exception E) {
					E.printStackTrace();
				}

			}
		});
		panel.add(discharge);

		JButton Check = new JButton("Check");
		Check.setBounds(350, 500, 120, 30);
		Check.setBackground(Color.black);
		Check.setForeground(Color.white);
		panel.add(Check);
		Check.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				DB_conn c = new DB_conn();

				selectedNumber = choice.getSelectedItem();

				try {
					String query = "SELECT p.*, d.fees, r.price FROM patient_info p " +
							"JOIN dr d ON p.drname = d.name " +
							"JOIN room r ON r.id = p.r_no " + // Assuming r_no in patient_info refers to the room ID
							"WHERE p.number = '" + selectedNumber + "'";
					ResultSet resultSet = c.sObj.executeQuery(query);
					if (resultSet.next()) {

						RNo.setText(resultSet.getString("name"));
						RNO1.setText(resultSet.getString("gender"));
						d2.setText(resultSet.getString("disease"));
						d3.setText(resultSet.getString("deposit"));
						INTime.setText(resultSet.getString("time"));
						dr_f2.setText(resultSet.getString("fees"));
						room_c2.setText(resultSet.getString("price"));
						extra2.setText("1200.10");
						total2.setText(String.valueOf(Double.parseDouble(room_c2.getText())
								+ Double.parseDouble(extra2.getText()) + Double.parseDouble(dr_f2.getText())));

					}

					// String inTimeStr = INTime.getText().trim(); // Get and trim the text from the INTime JLabel
					// if (!inTimeStr.isEmpty()) {
					// 	try {
					// 		SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
					// 		Date inTimeDate = sdf2.parse(inTimeStr); // Parse the string to a Date
					// 		String formattedDate = sdf2.format(inTimeDate); // Format the Date object
					// 		JOptionPane.showInternalMessageDialog(null, "INTime value: " + formattedDate); // Show the
					// 																						// formatted
					// 																						// date
					// 	} catch (ParseException ex) {
					// 		ex.printStackTrace();
					// 	}
					// }

				} catch (Exception e2) {
					e2.printStackTrace();
				}

			}

		});

		JButton findButton = new JButton("Find");
		findButton.setBounds(700, 500, 120, 30); // Set position for the Find button
		findButton.setBackground(Color.black);
		findButton.setForeground(Color.white);
		panel.add(findButton);

		// ActionListener for Find Button
		findButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// Prompt user for the 12-digit number
				String inputNumber = JOptionPane.showInputDialog("Enter 12-digit Patient Number:");

				// Check if the input is valid (12 digits)
				if (inputNumber != null && inputNumber.matches("\\d{12}")) {
					DB_conn c = new DB_conn();
					selectedNumber = inputNumber;

					try {
						String query = "SELECT p.*, d.fees, r.price FROM patient_info p " +
								"JOIN dr d ON p.drname = d.name " +
								"JOIN room r ON r.id = p.r_no " + // Assuming r_no in patient_info refers to the room ID
								"WHERE p.number = '" + selectedNumber + "'";
						ResultSet resultSet = c.sObj.executeQuery(query);
						if (resultSet.next()) {

							RNo.setText(resultSet.getString("name"));
							RNO1.setText(resultSet.getString("gender"));
							d2.setText(resultSet.getString("disease"));
							d3.setText(resultSet.getString("deposit"));
							INTime.setText(resultSet.getString("time"));

							dr_f2.setText(resultSet.getString("fees"));
							room_c2.setText(resultSet.getString("price"));
							extra2.setText("1200.10");
							total2.setText(String.valueOf(Double.parseDouble(room_c2.getText())
									+ Double.parseDouble(extra2.getText()) + Double.parseDouble(dr_f2.getText())));

						}
					} catch (Exception e2) {
						e2.printStackTrace();
					}
				} else {
					JOptionPane.showMessageDialog(null, "Please enter a valid 12-digit number.");
				}
			}
		});

		JButton Back = new JButton("Back");
		Back.setBounds(450, 500, 120, 30);
		Back.setBackground(Color.black);
		Back.setForeground(Color.white);
		panel.add(Back);
		Back.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
			}
		});

		JButton send = new JButton("Sending Bill...");
		send.setBounds(570, 500, 120, 30);
		send.setBackground(Color.black);
		send.setForeground(Color.white);
		// panel.add(send);
		send.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {

			}
		});// Create JLabel for displaying days

		// Add imports for TimeUnit

// ... (rest of your existing code)

JLabel day = new JLabel("/  Days");
day.setBounds(590, 340, 145, 20);
day.setFont(new Font("Tahoma", Font.BOLD, 14));
day.setForeground(Color.white);
// panel.add(day); // Add the day label to the panel



		setUndecorated(true);
		// setSize(800,400);
		setLayout(null);
		setBackground(Color.black);
		// setBounds(0, 0, 2450, 1700);
		setBounds(251, 23, 1116, 750);

		// setLocation(400,250);
		setVisible(true);

	}

	@Override
	public void actionPerformed(ActionEvent e) {

	}

	public static void main(String[] args) {
		new Discharge();
	}
}
