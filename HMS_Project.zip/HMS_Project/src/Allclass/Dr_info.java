package Allclass;


import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class Dr_info extends JFrame implements ActionListener {

	public Dr_info() {
		JFrame frame = new JFrame();

		JPanel panel = new JPanel();
		panel.setBounds(05, 05, 100, 700);
		panel.setBackground(Color.decode("#32233"));
		// panel.setVisible(true);
		frame.add(panel);

		// ------------------------Tabel-----------------------------
		DB_conn db = new DB_conn();
		String query = "SELECT dr.*, department.dpt_name FROM dr INNER JOIN department ON dr.dpt_name = department.dpt_name";


		// String query = "SELECT dr.*, department.dpt_name "
        //      + "FROM dr "
        //      + "INNER JOIN department ON dr.dpt_id = department.id";

		String[] columnNames = {"ID_Number","Name", "dpt_name", "Gender", "Exprinece", "Fees", "Ph_No","Age" 	};

		DefaultTableModel model = new DefaultTableModel(columnNames, 0) {
			@Override
			public boolean isCellEditable(int row, int column) {
				return false;
			};

		};

		try {
			ResultSet rs = db.sObj.executeQuery(query);

			while (rs.next()) {
				String Id_Number= rs.getString("ID_number");
				// String Id_Number= rs.getString("nu");
				String name = rs.getString("name");
				String dptID = rs.getString("dpt_name");
				String gender = rs.getString("gender");
				String exprience = rs.getString("experience");
				String fees = rs.getString("fees");
				String ph_number = rs.getString("phone");
				String age = rs.getString("age");
				

				model.addRow(new Object[] { Id_Number,name,dptID, gender, exprience, fees, ph_number,age });
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		JTable table = new JTable(model);
		JScrollPane scrollPane = new JScrollPane(table);
		table.getColumnModel().getColumn(3).setPreferredWidth(200);
		scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		table.setPreferredSize(new Dimension(300,250));

		JFrame frame2 = new JFrame("Patient Information");
// -------------------Close Button--------------------------
		JButton close=new JButton("Close");
		close.setFont(new Font("Tahoma", Font.BOLD, 17));
		close.setBounds(480,590,100,30);
		close.setForeground(Color.black);
		close.setBackground(Color.decode("#FF7F7F"));
		close.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
				// close.setVisible(false);
			}
		});

		frame2.add(close);
		frame2.add(scrollPane);
		frame.setFont(new Font("Tahoma", Font.PLAIN, 17));
		frame2.setBounds(251, 23, 1116, 750);
		frame2.setUndecorated(true);
		frame2.setVisible(true);
		panel.add(frame2);


	}
	@Override
	public void actionPerformed(ActionEvent e) {
		
	}
	public static void main(String[] args) {
		new Dr_info();

	}
}
