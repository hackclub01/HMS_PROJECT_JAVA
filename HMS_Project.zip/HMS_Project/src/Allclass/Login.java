package Allclass;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Arrays;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class Login extends JFrame implements ActionListener {
	JTextField tField;

	JPasswordField pField;
	JButton b1, b2;

	Login() {

		// Username Text
		JLabel idLabel = new JLabel("Username:");
		idLabel.setBounds(55, 270, 200, 30);
		idLabel.setFont(new Font("Tahoma", Font.BOLD, 16));
		idLabel.setForeground(Color.BLACK);
		add(idLabel);

		// Password Text/
		JLabel nLabel2 = new JLabel("Password:");
		nLabel2.setBounds(55, 300, 200, 30);
		nLabel2.setFont(new Font("Tahoma", Font.BOLD, 16));
		nLabel2.setForeground(Color.BLACK);
		add(nLabel2);
		// 00000000-=---------------0000000000000---------------000000000000000000----------

		// TextFiled ---Username
		tField = new JTextField();
		tField.setBounds(170, 270, 150, 25);
		tField.setFont(new Font("Tahoma", Font.PLAIN, 18));
		tField.setBackground(Color.yellow);
		add(tField);

		// TextFiled ---Password
		pField = new JPasswordField();
		pField.setBounds(170, 300, 150, 25);
		pField.setFont(new Font("Tahoma", Font.PLAIN, 15));
		pField.setBackground(Color.yellow);
		add(pField);

		// Adding Login Image----
		ImageIcon img = new ImageIcon(ClassLoader.getSystemResource("icon/roomm.png"));
		Image img1 = img.getImage().getScaledInstance(200, 200, Image.SCALE_DEFAULT);
		ImageIcon img2 = new ImageIcon(img1);
		JLabel imgLabel = new JLabel(img2);
		imgLabel.setBounds(25, -40, 380, 350);
		add(imgLabel);

		// Login Button
		b1 = new JButton("Login");
		b1.setBounds(60, 380, 120, 30);
		b1.setFont(new Font("serif", Font.BOLD, 15));
		b1.setBackground(Color.BLACK);
		b1.setForeground(Color.white);
		b1.addActionListener(this);
		add(b1);
		b1.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// setVisible(false);
				// String uname=tField.getText();
				
char p[] = pField.getPassword();
if (Arrays.equals(p, "code10".toCharArray())) {  // Compare using Arrays.equals()
    new Reception();
} else {
    JOptionPane.showInternalMessageDialog(null, "Wrong Password:");
}
			}
		});

		// Cancel Button
		b2 = new JButton("Cencel");
		b2.setBounds(210, 380, 120, 30);
		b2.setFont(new Font("serif", Font.BOLD, 15));
		b2.setBackground(Color.BLACK);
		b2.setForeground(Color.white);
		b2.addActionListener(this);
		add(b2);
		b2.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				System.exit(190);
			}

		});

		getContentPane().setBackground(new Color(109, 164, 170));
		setBounds(400, 100, 450, 500);
		setLayout(null);
		setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {

	}

	public static void main(String[] args) throws Exception {
		new Login();

	}

}
