package Allclass;

import java.awt.Choice;
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

public class Add_patient extends JFrame implements ActionListener {
	JComboBox comboBox;
	JTextField textFieldNumber, textName, textFieldDisease, textFieldDeposite, dr, textFieldContact;
	JRadioButton r1, r2;
	Choice c1, c3, c11, c4;
	JLabel date;
	JButton b1, b2;

	Add_patient() {

		JPanel panel = new JPanel();
		panel.setBounds(5, 5, 1200, 900);
		panel.setBackground(new Color(90, 156, 163));
		panel.setLayout(null);
		add(panel);

		ImageIcon imageIcon = new ImageIcon(ClassLoader.getSystemResource("icon/patient2.png"));
		Image image = imageIcon.getImage().getScaledInstance(250, 250, Image.SCALE_SMOOTH);
		ImageIcon imageIcon1 = new ImageIcon(image);
		JLabel label = new JLabel(imageIcon1);
		label.setBounds(590, 70, 290, 290);
		panel.add(label);

		JLabel labelName = new JLabel("NEW PATIENT FORM");
		labelName.setBounds(160, 8, 260, 53);
		labelName.setFont(new Font("Tahoma", Font.BOLD, 24));
		panel.add(labelName);

		JLabel labelID = new JLabel("ID :");
		labelID.setBounds(145, 76, 200, 16);
		labelID.setFont(new Font("Tahoma", Font.BOLD, 16));
		labelID.setForeground(Color.white);
		panel.add(labelID);

		// comboBox = new JComboBox(new String[] { "Aadhar Card", "Voter Id", "Driving
		// License" });
		// comboBox.setBounds(350, 73, 150, 20);
		// comboBox.setBackground(new Color(3, 45, 48));
		// comboBox.setForeground(Color.white);
		// comboBox.setFont(new Font("Tahoma", Font.BOLD,16));
		// panel.add(comboBox);

		comboBox = new JComboBox(new String[] { "Aadhar card" });
		comboBox.setBounds(350, 73, 150, 20);
		comboBox.setBackground(new Color(3, 45, 48));
		comboBox.setForeground(Color.white);
		comboBox.setFont(new Font("Tahoma", Font.BOLD, 16));
		panel.add(comboBox);

		JLabel labelNumber = new JLabel("Number :");
		labelNumber.setBounds(145, 111, 200, 16);
		labelNumber.setFont(new Font("Tahoma", Font.BOLD, 16));
		labelNumber.setForeground(Color.white);
		panel.add(labelNumber);

		textFieldNumber = new JTextField();
		textFieldNumber.setBounds(350, 111, 150, 20);
		panel.add(textFieldNumber);

		JLabel labelName1 = new JLabel("Name :");
		labelName1.setBounds(145, 151, 200, 16);
		labelName1.setFont(new Font("Tahoma", Font.BOLD, 16));
		labelName1.setForeground(Color.white);
		panel.add(labelName1);

		textName = new JTextField();
		textName.setBounds(350, 151, 150, 20);
		panel.add(textName);

		JLabel labelGender = new JLabel("Gender :");
		labelGender.setBounds(145, 191, 200, 16);
		labelGender.setFont(new Font("Tahoma", Font.BOLD, 16));
		labelGender.setForeground(Color.white);
		panel.add(labelGender);

		r1 = new JRadioButton("Male");
		r1.setFont(new Font("Tahoma", Font.BOLD, 16));
		r1.setForeground(Color.white);
		r1.setBackground(new Color(109, 164, 170));
		r1.setBounds(350, 191, 80, 15);
		panel.add(r1);

		r2 = new JRadioButton("Female");
		r2.setFont(new Font("Tahoma", Font.BOLD, 16));
		r2.setForeground(Color.white);
		r2.setBackground(new Color(109, 164, 170));
		r2.setBounds(430, 191, 80, 15);
		panel.add(r2);

		JLabel labelDisease = new JLabel("Disease :");
		labelDisease.setBounds(145, 231, 200, 16);
		labelDisease.setFont(new Font("Tahoma", Font.BOLD, 16));
		labelDisease.setForeground(Color.white);
		panel.add(labelDisease);

		c3 = new Choice();
		c3.setBounds(350, 230, 150, 25);
		panel.add(c3);

		try {
			DB_conn c = new DB_conn();
			ResultSet resultSet = c.sObj.executeQuery("select * from department");
			while (resultSet.next()) {
				c3.add(resultSet.getString("dpt_name"));
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		JLabel drname = new JLabel("Doctor :");
		drname.setBounds(145, 260, 200, 16);
		drname.setFont(new Font("Tahoma", Font.BOLD, 16));
		drname.setForeground(Color.white);
		panel.add(drname);

		c4 = new Choice();
		c4.setBounds(350, 260, 150, 25);
		panel.add(c4);

		// JOptionPane.showInternalMessageDialog(null, c3.getSelectedItem());

		c3.addItemListener(new ItemListener() {
			@Override
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					String selectedDepartment = c3.getSelectedItem();
					c4.removeAll(); // Clear previous entries

					try {
						DB_conn c = new DB_conn();
						ResultSet resultSet = c.sObj
								.executeQuery("SELECT name FROM dr WHERE dpt_name = '" + selectedDepartment + "'");
						while (resultSet.next()) {
							c4.add(resultSet.getString("name"));
						}
					} catch (Exception ex) {
						ex.printStackTrace();
					}
				}
			}
		});

		JLabel labelRoom = new JLabel("Room :");
		labelRoom.setBounds(145, 284, 200, 16);
		labelRoom.setFont(new Font("Tahoma", Font.BOLD, 16));
		labelRoom.setForeground(Color.white);
		panel.add(labelRoom);

		c11 = new Choice();
		try {
			DB_conn c = new DB_conn();
			ResultSet result = c.sObj.executeQuery("SELECT * FROM room where status='Available'");
			// JOptionPane.showInternalMessageDialog(null,c1.getSelectedItem());
			while (result.next()) {

				c11.add(result.getString("id"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		c11.addItemListener(new ItemListener() {
			@Override
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					String selectedRoomId = c11.getSelectedItem();
					try {
						DB_conn c = new DB_conn();
						// Corrected query to update the room status
						JOptionPane.showInternalMessageDialog(null,selectedRoomId);
						String updateQuery = "UPDATE room SET status = 'Unavailable' WHERE id = '" + selectedRoomId
								+ "'";
						// Execute the update query
						c.sObj.executeUpdate(updateQuery);
					} catch (Exception ex) {
						ex.printStackTrace();
					}
				}
			}
		});

		c11.setBounds(450, 284, 50, 20);
		c11.setFont(new Font("Tahoma", Font.BOLD, 16));
		c11.setForeground(Color.WHITE);
		c11.setBackground(new Color(3, 45, 48));
		panel.add(c11);

		JLabel labelDate = new JLabel("Time :");
		labelDate.setBounds(145, 316, 200, 16);
		labelDate.setFont(new Font("Tahoma", Font.BOLD, 16));
		labelDate.setForeground(Color.white);
		panel.add(labelDate);

		Date date1 = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:MM:ss");
		String correctDate = sdf.format(date1);

		date = new JLabel("" + correctDate);
		date.setBounds(350, 316, 250, 16);
		date.setForeground(Color.white);
		date.setFont(new Font("Tahoma", Font.BOLD, 16));
		panel.add(date);

		JLabel labelDeposite = new JLabel("Deposite :");
		labelDeposite.setBounds(145, 349, 200, 17);
		labelDeposite.setFont(new Font("Tahoma", Font.BOLD, 16));
		labelDeposite.setForeground(Color.white);
		panel.add(labelDeposite);

		textFieldDeposite = new JTextField();
		textFieldDeposite.setBounds(350, 349, 150, 20);
		panel.add(textFieldDeposite);

		JLabel contact = new JLabel("contact :");
		contact.setBounds(145, 389, 200, 17);
		contact.setFont(new Font("Tahoma", Font.BOLD, 16));
		contact.setForeground(Color.white);
		panel.add(contact);

		textFieldContact = new JTextField();
		textFieldContact.setBounds(350, 389, 150, 20);
		panel.add(textFieldContact);

		// JLabel drName = new JLabel("Dr_name :");
		// drName.setBounds(145, 381, 200,16);
		// drName.setFont(new Font("Tahoma", Font.BOLD,16));
		// drName.setForeground(Color.white);
		// panel.add(drName);

		// c3=new Choice();
		// try{
		// DB_conn c=new DB_conn();
		// ResultSet result=c.sObj.executeQuery("select * from room");
		// while(result.next())
		// {
		// c3.add(result.getString("type"));
		// }

		// }catch(Exception e)
		// {e.printStackTrace();}

		// c3.setBounds(350, 381, 150, 20);
		// panel.add(c3);

		b1 = new JButton("ADD");
		b1.setBounds(200, 430, 120, 30);
		b1.setForeground(Color.WHITE);
		b1.setBackground(Color.black);
		b1.addActionListener(this);
		panel.add(b1);

		b2 = new JButton("Back");
		b2.setBounds(460, 430, 120, 30);
		b2.setForeground(Color.WHITE);
		b2.setBackground(Color.black);
		b2.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
			}
		});
		panel.add(b2);

		setUndecorated(true);
		setSize(850, 550);
		setLayout(null);
		// setLocation(300, 250);
		setBounds(251, 24, 1116, 750);

		setVisible(true);

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == b1) {
			DB_conn c = new DB_conn();
			String radioBTN = null;
			if (r1.isSelected()) {
				radioBTN = "Male";
			} else if (r2.isSelected()) {
				radioBTN = "Female";
			}

			// String s1 =(String) comboBox.getSelectedItem();
			String s2 = textFieldNumber.getText();
			String s3 = textName.getText();
			String s4 = radioBTN;
			String s5 = c3.getSelectedItem();
			String s6 = c11.getSelectedItem();

			String s7 = date.getText();
			String s8 = textFieldDeposite.getText();
			String s9 = textFieldContact.getText();
			String s10 = c4.getSelectedItem();

			boolean isValid = true;

			if (s2 == null || s2.isEmpty()) {
				isValid = false;
				// Handle validation failure for s2
			}
			if (s3 == null || s3.isEmpty()) {
				isValid = false;
				// Handle validation failure for s3
			}
			if (s4 == null || s4.isEmpty()) {
				isValid = false;
				// Handle validation failure for s4
			}
			if (s5 == null || s5.isEmpty()) {
				isValid = false;
				// Handle validation failure for s5
			}

			if (s7 == null || s7.isEmpty()) {
				isValid = false;
				// Handle validation failure for s7
			}
			if (s8 == null || s8.isEmpty()) {
				isValid = false;
				// Handle validation failure for s8
			}

			if (isValid) {
				try {

					String q = "insert into Patient_Info values ( '" + s2 + "','" + s3 + "','" + s4 + "', '"
							+ s5 + "' ,'" + s6 + "', '" + s7 + "', '" + s8 + "','" + s9 + "','"+s10+"')";
					// String q1 = "update room set status = 'Occupied' where room_no = " + s6;
					c.sObj.executeUpdate(q);
					// c.sObj.executeUpdate(q1);
					JOptionPane.showMessageDialog(null, "added Successfully");
					setVisible(false);
					// setVisible(false);

				} catch (Exception E) {
					E.printStackTrace();
				}
			} else {

				JOptionPane.showMessageDialog(null, "Fill Up Again");
				System.out.println("Check Again And Fillup");

			}
		}

	}

	public static void main(String[] args) {
		new Add_patient();
	}

}
