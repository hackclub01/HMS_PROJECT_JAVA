package Allclass;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class patient_info extends JFrame implements ActionListener {

	public patient_info() {
		JFrame frame = new JFrame();

		JPanel panel = new JPanel();
		panel.setBounds(05, 05, 100, 700);
		panel.setBackground(Color.decode("#32233"));
		// panel.setVisible(true);
		frame.add(panel);

		// ------------------------Tabel-----------------------------
		DB_conn db = new DB_conn();

		String query = "SELECT * FROM patient_info";

		String[] columnNames = { "Id_Number", "Name", "Gender", "Disease", "Room No", "Time", "Contact" };

		DefaultTableModel model = new DefaultTableModel(columnNames, 0) {
			@Override
			public boolean isCellEditable(int row, int column) {
				return true;
			};

		};

		try {
			ResultSet rs = db.sObj.executeQuery(query);

			while (rs.next()) {
				// String id = rs.getString("id");
				String number = rs.getString("number");
				String name = rs.getString("name");
				String gender = rs.getString("gender");
				String disease = rs.getString("disease");
				String r_no = rs.getString("r_no");
				String time = rs.getString("time");
				String Contact = rs.getString("contact");

				model.addRow(new Object[] { number, name, gender, disease, r_no, time, Contact });
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		JTable table = new JTable(model);
		JScrollPane scrollPane = new JScrollPane(table);
		table.getColumnModel().getColumn(3).setPreferredWidth(200);
		scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		table.setPreferredSize(new Dimension(300, 250));

		JFrame frame2 = new JFrame("Patient Information");
		// -------------------Close Button--------------------------
		JButton close = new JButton("Close");
		close.setFont(new Font("Tahoma", Font.BOLD, 17));
		close.setBounds(480, 590, 100, 30);
		close.setForeground(Color.black);
		close.setBackground(Color.decode("#FF7F7F"));
		close.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});

		JButton find = new JButton("Find");
		find.setForeground(Color.black);
		find.setFont(new Font("Tahoma", Font.BOLD, 14));
		find.setBounds(580, 590, 100, 30);

		find.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {

				String find = JOptionPane.showInputDialog("Name Here");
				try {
					DB_conn c = new DB_conn();
					String q2 = "select * from patient_info where name='" + find + "'";
					ResultSet rs = c.sObj.executeQuery(q2);
					model.setRowCount(0);
					while (rs.next()) {

						JPanel panel= new JPanel();
						panel.setBounds(5, 5, 1990, 890);
						panel.setBackground(new Color(109, 164, 170));
						panel.setLayout(null);
						add(panel);
						// String id = rs.getString("id");
						String number = rs.getString("number");
						String name = rs.getString("name");
						String gender = rs.getString("gender");
						String disease = rs.getString("disease");
						String r_no = rs.getString("r_no");
						String time = rs.getString("time");
						String Contact = rs.getString("contact");

						model.addRow(new Object[] { number,name, gender,disease,r_no,time,Contact });
						// JOptionPane.showInternalMessageDialog(null, "s");

					}
					if (model.getRowCount() == 0) {
						JOptionPane.showMessageDialog(null, "No records found for ID: " + find);
					}
				} catch (Exception e2) {
					e2.printStackTrace();
					;
				}

			}

		});
		frame2.add(find);

		frame2.add(close);
		frame2.add(scrollPane);
		frame.setFont(new Font("Tahoma", Font.PLAIN, 17));
		frame2.setBounds(251, 23, 1116, 750);
		frame2.setUndecorated(true);
		frame2.setVisible(true);
		panel.add(frame2);

	}

	@Override
	public void actionPerformed(ActionEvent e) {

	}

	public static void main(String[] args) {
		new patient_info();

	}
}
