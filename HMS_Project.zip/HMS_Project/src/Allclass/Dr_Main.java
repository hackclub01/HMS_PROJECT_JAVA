package Allclass;

import java.awt.Choice;
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

public class Dr_Main extends JFrame implements ActionListener {
	JTextField textFieldNumber, textName,textage, exText, fText, PText, dr;
	JRadioButton r1, r2;
	Choice c1, c3;
	JButton b1, b2;
	// Map<String, String> departmentMap = new HashMap<>();

	Dr_Main() {
		JPanel panel = new JPanel();
		panel.setBounds(5, 5, 1200, 900);
		panel.setBackground(new Color(90, 156, 163));
		panel.setLayout(null);
		add(panel);

		ImageIcon imageIcon = new ImageIcon(ClassLoader.getSystemResource("icon/dr.png"));
		Image image = imageIcon.getImage().getScaledInstance(250, 250, Image.SCALE_SMOOTH);
		ImageIcon imageIcon1 = new ImageIcon(image);
		JLabel label = new JLabel(imageIcon1);
		label.setBounds(590, 70, 290, 290);
		panel.add(label);

		JLabel labelName = new JLabel("NEW DOCTOR FORM");
		labelName.setBounds(160, 8, 260, 53);
		labelName.setFont(new Font("Tahoma", Font.BOLD, 24));
		panel.add(labelName);

		JLabel labelID = new JLabel("ID-Card:");
		labelID.setBounds(145, 76, 200, 16);
		labelID.setFont(new Font("Tahoma", Font.BOLD, 16));
		labelID.setForeground(Color.white);
		panel.add(labelID);

		JComboBox<String> comboBox = new JComboBox<>(new String[] { "Aadhar card", "Pan Card" });
		comboBox.setBounds(350, 73, 150, 20);
		comboBox.setBackground(new Color(3, 45, 48));
		comboBox.setForeground(Color.white);
		comboBox.setFont(new Font("Tahoma", Font.BOLD, 16));
		panel.add(comboBox);

		JLabel labelNumber = new JLabel("Number :");
		labelNumber.setBounds(145, 111, 200, 16);
		labelNumber.setFont(new Font("Tahoma", Font.BOLD, 16));
		labelNumber.setForeground(Color.white);
		panel.add(labelNumber);

		textFieldNumber = new JTextField();
		textFieldNumber.setBounds(350, 111, 150, 20);
		panel.add(textFieldNumber);

		JLabel labelName1 = new JLabel("Name :");
		labelName1.setBounds(145, 151, 200, 16);
		labelName1.setFont(new Font("Tahoma", Font.BOLD, 16));
		labelName1.setForeground(Color.white);
		panel.add(labelName1);

		textName = new JTextField();
		textName.setBounds(350, 151, 150, 20);
		panel.add(textName);

		JLabel labelGender = new JLabel("Gender :");
		labelGender.setBounds(145, 191, 200, 16);
		labelGender.setFont(new Font("Tahoma", Font.BOLD, 16));
		labelGender.setForeground(Color.white);
		panel.add(labelGender);

		r1 = new JRadioButton("Male");
		r1.setFont(new Font("Tahoma", Font.BOLD, 14));
		r1.setForeground(Color.white);
		r1.setBackground(new Color(109, 164, 170));
		r1.setBounds(350, 191, 80, 15);
		panel.add(r1);

		r2 = new JRadioButton("Female");
		r2.setFont(new Font("Tahoma", Font.BOLD, 13));
		r2.setForeground(Color.white);
		r2.setBackground(new Color(109, 164, 170));
		r2.setBounds(430, 191, 80, 15);
		panel.add(r2);

		JLabel labelDepartment = new JLabel("Department :");
		labelDepartment.setBounds(145, 231, 200, 16);
		labelDepartment.setFont(new Font("Tahoma", Font.BOLD, 16));
		labelDepartment.setForeground(Color.white);
		panel.add(labelDepartment);

		c1 = new Choice();
		try {
			DB_conn c = new DB_conn();
			ResultSet result = c.sObj.executeQuery("SELECT  dpt_name FROM department");
			while (result.next()) {
				// String id = result.getString("id");
				String dName = result.getString("dpt_name");
				c1.add(dName);
				// departmentMap.put(dpt_name, id);
				// JOptionPane.showInternalMessageDialog(c1,"value in varable");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		c1.setBounds(350, 225, 150, 20);
		c1.setFont(new Font("Tahoma", Font.BOLD, 16));
		c1.setForeground(Color.WHITE);
		c1.setBackground(new Color(3, 45, 48));
		panel.add(c1);

		JLabel labelExperience = new JLabel("Experience :");
		labelExperience.setBounds(145, 261, 200, 16);
		labelExperience.setFont(new Font("Tahoma", Font.BOLD, 16));
		labelExperience.setForeground(Color.white);
		panel.add(labelExperience);

		exText = new JTextField();
		exText.setBounds(350, 261, 150, 20);
		panel.add(exText);

		JLabel labelFees = new JLabel("Fees :");
		labelFees.setBounds(145, 300, 200, 16);
		labelFees.setFont(new Font("Tahoma", Font.BOLD, 16));
		labelFees.setForeground(Color.white);
		panel.add(labelFees);

		fText = new JTextField();
		fText.setBounds(350, 300, 150, 20);
		panel.add(fText);


		JLabel age = new JLabel("Age :");
		age.setBounds(145, 331, 205, 16);
		age.setFont(new Font("Tahoma", Font.BOLD, 16));
		age.setForeground(Color.white);
		panel.add(age);

		
		textage = new JTextField();
		textage.setBounds(350, 331, 150, 20);
		panel.add(textage);
		
		JLabel ph = new JLabel("Phone_No:");
		ph.setBounds(145, 360, 200, 16);
		ph.setFont(new Font("Tahoma", Font.BOLD, 16));
		ph.setForeground(Color.white);
		panel.add(ph);

		PText = new JTextField();
		PText.setBounds(350, 360, 150, 20);
		panel.add(PText);


		b1 = new JButton("ADD");
		b1.setBounds(145, 430, 120, 30);
		b1.setForeground(Color.WHITE);
		b1.setBackground(Color.black);
// --------------------------------------------------------------------------------------------------------------------------
b1.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
        // Retrieve the values from input fields
        String name = textName.getText();
        String number = textFieldNumber.getText();
        String phone = PText.getText();
        String experience = exText.getText();
        String fees = fText.getText();
		String age2=textage.getText();
     
        // Validate the inputs
        boolean isValid = true;
        
        // Name validation: only characters
        if (name == null || name.isEmpty() || !name.matches("[a-zA-Z ]+")) {
            isValid = false;
            JOptionPane.showMessageDialog(null, "Name must contain only characters.");
        }
        
        // Number validation: must be 10 or 12 digits
		if (number == null || (!number.matches("\\d{10}") && !number.matches("\\d{12}"))) {
            isValid = false;
            JOptionPane.showMessageDialog(null, "Number must be either 10 or 12 digits.");
        } 
        // Phone validation: must be exactly 10 digits
        if (phone == null || !phone.matches("\\d{10}")) {
            isValid = false;
            JOptionPane.showMessageDialog(null, "Phone number must be exactly 10 digits.");
        }
        
        // Experience validation: must be less than 50
        if (experience == null || experience.isEmpty() || Integer.parseInt(experience) >= 50) {
            isValid = false;
            JOptionPane.showMessageDialog(null, "Experience must be less than 50 years.");
        }
        
        // Fee validation: must not exceed 50,000
        if (fees == null || fees.isEmpty() || Integer.parseInt(fees) > 50000) {
            isValid = false;
            JOptionPane.showMessageDialog(null, "Fee must not exceed 50,000.");
        }

        // Check if department is selected
        // String selectedDepartmentName = (String) c1.getSelectedItem();
        if (c1.getSelectedItem() == null || c1.getSelectedItem().isEmpty()) {
            isValid = false;
            JOptionPane.showMessageDialog(null, "Please select a department.");
        }  
        
        // Proceed with database operation if all validations pass
        if (isValid) {
            try {
                DB_conn c = new DB_conn();
                // String selectedDepartmentId = departmentMap.get(selectedDepartmentName); // Get department ID
				

                String q = "INSERT INTO dr (name, gender, experience, fees, ID_number, phone,dpt_name,age) VALUES ('"
                        + name + "', '"
                        + (r1.isSelected() ? "Male" : "Female") + "', '"
                        + experience + "', '"
                        + fees + "', '"
                        + number + "', '"
                        + phone + "', '"
                        + c1.getSelectedItem() + "','"+
						age2+"')";

                int result = c.sObj.executeUpdate(q);
                if (result > 0) {
                    JOptionPane.showMessageDialog(null, "Doctor added successfully!");
                }
            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(null, "An error occurred while adding the doctor.");
            }
        }
	}
});


		panel.add(b1);

		b2 = new JButton("Back");
		b2.setBounds(350, 430, 120, 30);
		b2.setForeground(Color.WHITE);
		b2.setBackground(Color.black);
		b2.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
			}
		});
		panel.add(b2);

		setUndecorated(true);
		setSize(850, 550);
		setLayout(null);
		setBounds(251, 24, 1116, 750);
		setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
	}

	public static void main(String[] args) {
		new Dr_Main();
	}
}
