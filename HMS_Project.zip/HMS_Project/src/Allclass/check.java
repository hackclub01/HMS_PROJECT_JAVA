package Allclass;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.table.DefaultTableModel;

public class check extends JFrame implements ActionListener {
	check() {
		DB_conn c = new DB_conn();

		JPanel p1 = new JPanel();
		p1.setBounds(5, 5, 300, 400);
		p1.setBackground(Color.LIGHT_GRAY);
		add(p1);

		JButton b1 = new JButton("Add");
		b1.setBounds(20, 20, 50, 30);
		b1.setBackground(Color.cyan);
		b1.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				JFrame childWindow = new JFrame("Child Window");
				childWindow.setBounds(0, 0, 700, 700);

				JPanel p2 = new JPanel();
				p2.setLayout(null); // Setting layout to null for manual positioning
				p2.setBounds(0, 0, 700, 700);
				p2.setBackground(Color.lightGray);
				childWindow.add(p2);

				JLabel username = new JLabel("Username:");
				username.setBounds(155, 50, 100, 50);
				username.setFont(new Font("Tahoma", Font.BOLD, 16));
				username.setForeground(Color.BLACK);
				p2.add(username); // Add label to panel

				JTextArea username2 = new JTextArea();
				username2.setBounds(250, 65, 100, 20); // Set position within the panel
				p2.add(username2); // Add text area to the panel

				JLabel pass = new JLabel("Password:");
				pass.setBounds(155, 100, 100, 50);
				pass.setFont(new Font("Tahoma", Font.BOLD, 16));
				p2.add(pass);

				JTextArea pass2 = new JTextArea();
				pass2.setBounds(250, 113, 100, 20);
				p2.add(pass2);

				JButton sendData = new JButton("Send");
				sendData.setForeground(Color.RED);
				sendData.setBounds(250, 150, 100, 30);
				sendData.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						try {
							// ------------Data Sendding -----------------
							String uname = username2.getText();
							String pass3 = pass2.getText();
							String age = "21";
							String Q = "insert into user values('" + uname + "','" + pass3 + "'," + age + ")";

							c.sObj.executeUpdate(Q);
							JOptionPane.showInternalMessageDialog(null, "Data Adding SuccessFully..!!");

						} catch (Exception e2) {
							e2.printStackTrace();
						}
					}
				});
				p2.add(sendData);

				childWindow.setVisible(true);

			}
		});

		p1.add(b1);

		JButton b2 = new JButton("Read");
		b2.setBounds(20, 20, 50, 30);
		b2.setBackground(Color.cyan);
		b2.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				JFrame childWindow = new JFrame("Data Table");
				childWindow.setSize(700, 700);

				String Q = "select * from user";
				String columnname[] = { "name", "password", "age" };
				DefaultTableModel model = new DefaultTableModel(columnname, 0);
				try {
					ResultSet result = c.sObj.executeQuery(Q);
					while (result.next()) {
						String n = result.getString("name");
						String p = result.getString("password");
						String a = result.getString("age");
						model.addRow(new Object[] { n, p, a });
					}
					JTable table = new JTable(model);
					JScrollPane tableScroll = new JScrollPane(table);
					table.setPreferredScrollableViewportSize(new Dimension(300, 150));
					childWindow.add(tableScroll);

				} catch (Exception e3) {
					e3.printStackTrace();
				}

				childWindow.setVisible(true);
			}
		});

		p1.add(b2);

		p1.add(b2);

		JButton b3 = new JButton("Update");
		b3.setBounds(20, 20, 50, 30);
		b3.setBackground(Color.cyan);
		b3.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
				
				String name=JOptionPane.showInputDialog("Enter Name Where You Chnage---");
				String name2=JOptionPane.showInputDialog("Enter new Name");
				String pass=JOptionPane.showInputDialog("Enter pass");
				String age=JOptionPane.showInputDialog("Enter age");
				// String Q="Update user SET name='"+name+'",'pass='"'+pass+''age='"+age+'";
				String Q="UPDATE user SET name='"+name2+"',password='"+pass+"',age='"+age+"'WHERE name='"+name+"'";
				c.sObj.executeUpdate(Q);
				JOptionPane.showMessageDialog(null,"Update Successfully");
				} catch (Exception e3) {
					e3.printStackTrace();
				}
			}
		});
		p1.add(b3);

		JButton b4 = new JButton("Delete");
		b4.setBounds(20, 20, 50, 30);
		b4.setBackground(Color.cyan);
		b4.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					String name = JOptionPane.showInputDialog("Enter Name Here");
					String Q = "Delete From user where name='" + name + "'";
					Integer n=c.sObj.executeUpdate(Q);
					if(n==0)
					{
						JOptionPane.showInternalMessageDialog(null,"Row Can't Find");

					}
					else{ 
					JOptionPane.showInternalMessageDialog(null,"Delete Row Successfully");

					}

				} catch (Exception e4) {
					e4.printStackTrace();

				}
			}
		});
		p1.add(b4);

		setBounds(50, 20, 500, 500);
		setVisible(true);

	}

	@Override
	public void actionPerformed(ActionEvent e) {

	}

	public static void main(String args[]) {
		new check();
	}
}